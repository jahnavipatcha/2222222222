package com.cg.university.entity;
import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name="ProgramsOffered")
public class ProgramsOffered implements Serializable{

    @Id
    @Column(name="programName")
    @NotEmpty(message = "Description is mandatory")
    @Size(min=3,max=15,message="minimum 3 letters")
	private String programName;
    @NotEmpty(message = "Description is mandatory")
    @Size(min=3,max=20,message="minimum 3 letters")
	private String description;	
    @NotEmpty(message = "ApplicantEligibility is mandatory")
    @Size(min=3,max=15,message="minimum 3 letters")
	private String applicantEligibility;	
    @NotEmpty(message = "Duration is mandatory")
    @Size(min=2,max=10,message="minimum 3 letters")
	private String duration;	
    @NotEmpty(message = "DegreeCertificate is mandatory")
	private String degreeCertificate;
	
	@JsonIgnore
    @OneToMany(mappedBy = "programsOffered")
	private List<ProgramsScheduled> programScheduled;

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getApplicantEligibility() {
		return applicantEligibility;
	}

	public void setApplicantEligibility(String applicantEligibility) {
		this.applicantEligibility = applicantEligibility;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getDegreeCertificate() {
		return degreeCertificate;
	}

	public void setDegreeCertificate(String degreeCertificate) {
		this.degreeCertificate = degreeCertificate;
	}

	public List<ProgramsScheduled> getProgramScheduled() {
		return programScheduled;
	}

	public void setProgramScheduled(List<ProgramsScheduled> programScheduled) {
		this.programScheduled = programScheduled;
	}
	 
}
