package com.cg.university.entity;
import java.io.Serializable;
import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;



@Data
@Entity
@JsonIgnoreProperties({ "hibernateLazyInitializer","handler" })
@Table(name="ProgramsScheduled")
public class ProgramsScheduled implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id 
	@Column(name="scheduledProgramID")
	@SequenceGenerator(name="myseq",sequenceName ="program_seq", initialValue= 100, allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="myseq")
	private int scheduledProgramID;
	@NotEmpty(message = "ProgramName is Mandatory")	
	private String programName;
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="programName",insertable = false,updatable = false)
	private ProgramsOffered programsOffered;
	@NotEmpty(message = "Location is mandatory")
	private String location;
	@NotEmpty(message = "StartDate is mandatory")
	private String startDate;
	@NotEmpty(message = "EndDate is mandatory")
	private String endDate;
	@NotNull(message = "SessionPerWeek is mandatory")
	private String sessionPerWeek;
	@JsonIgnore
	@OneToMany(mappedBy = "programsScheduled")
	private List<Application> application;
	public int getScheduledProgramID() {
		return scheduledProgramID;
	}
	public void setScheduledProgramID(int scheduledProgramID) {
		this.scheduledProgramID = scheduledProgramID;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public ProgramsOffered getProgramsOffered() {
		return programsOffered;
	}
	public void setProgramsOffered(ProgramsOffered programsOffered) {
		this.programsOffered = programsOffered;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getSessionPerWeek() {
		return sessionPerWeek;
	}
	public void setSessionPerWeek(String sessionPerWeek) {
		this.sessionPerWeek = sessionPerWeek;
	}
	public List<Application> getApplication() {
		return application;
	}
	public void setApplication(List<Application> application) {
		this.application = application;
	}
	
	

	 
	
}
