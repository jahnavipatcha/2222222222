package com.cg.university.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.Data;


@Entity
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Application implements Serializable {
	  
	  @Id	  
	  @Column(name="applicationId")	  
	  @SequenceGenerator(name="applicationseq",
	  sequenceName="application_seq",initialValue= 100,allocationSize=1)	  
	  @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="applicationseq")
		private int applicationId;
	    
	    @NotNull(message="fullname is mandatory")
        private String fullName;
	    @NotNull(message="DateOfBirth is mandatory")
	    private String dateOfBirth;
	    @NotNull(message="HighestQualification is mandatory")
        private String highestQualification;
	    @NotNull(message="MarksObtained is mandatory")
		private int marksObtained;
	    @NotNull(message="Goal is mandatory")
		private String goals;
	    @NotNull(message="EmailID is mandatory")
		private String emailID;
		private String status="applied";
	    private Date dateOfInterview;
	    @NotNull(message="ScheduledProgramID is mandatory")
	    private int scheduledProgramID;
	    @JsonIgnore
		@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	    @JoinColumn(name = "scheduledProgramID",insertable = false,updatable = false)
		private ProgramsScheduled programsScheduled;
		public int getApplicationId() {
			return applicationId;
		}
		public void setApplicationId(int applicationId) {
			this.applicationId = applicationId;
		}
		public String getFullName() {
			return fullName;
		}
		public void setFullName(String fullName) {
			this.fullName = fullName;
		}
		public String getDateOfBirth() {
			return dateOfBirth;
		}
		public void setDateOfBirth(String dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}
		public String getHighestQualification() {
			return highestQualification;
		}
		public void setHighestQualification(String highestQualification) {
			this.highestQualification = highestQualification;
		}
		public int getMarksObtained() {
			return marksObtained;
		}
		public void setMarksObtained(int marksObtained) {
			this.marksObtained = marksObtained;
		}
		public String getGoals() {
			return goals;
		}
		public void setGoals(String goals) {
			this.goals = goals;
		}
		public String getEmailID() {
			return emailID;
		}
		public void setEmailID(String emailID) {
			this.emailID = emailID;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public Date getDateOfInterview() {
			return dateOfInterview;
		}
		public void setDateOfInterview(Date dateOfInterview) {
			this.dateOfInterview = dateOfInterview;
		}
		public int getScheduledProgramID() {
			return scheduledProgramID;
		}
		public void setScheduledProgramID(int scheduledProgramID) {
			this.scheduledProgramID = scheduledProgramID;
		}
		public ProgramsScheduled getProgramsScheduled() {
			return programsScheduled;
		}
		public void setProgramsScheduled(ProgramsScheduled programsScheduled) {
			this.programsScheduled = programsScheduled;
		}
	
	
	
	
}